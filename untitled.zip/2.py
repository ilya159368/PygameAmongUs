import os
import sys
import pygame

pygame.init()
pygame.key.set_repeat(200, 70)
FPS = 50
WIDTH = 500
HEIGHT = 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
player = None
all_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


# ____картинки____
tile_imgs = {
    'wall': load_image('box.png'),
    'empty': load_image('grass.png')
}
player_img = load_image('mario.png')
tile_width = tile_height = STEP = 50


class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, x, y):
        super().__init__(tiles_group, all_sprites)
        self.image = tile_imgs[tile_type]
        self.rect = self.image.get_rect().move(
            tile_width * x, tile_height * y)


class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__(player_group, all_sprites)
        self.image = player_img
        self.rect = self.image.get_rect().move(
            tile_width * x + 15, tile_height * y + 5)


def load_level(file):
    file = 'data/' + file
    with open(file, 'r') as game_map:
        levels = [line.strip() for line in game_map]
    mx_width = max(map(len, levels))
    return list(map(lambda x: x.ljust(mx_width, '.'), levels))


def generate_level(level):
    new_player, x, y = None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                Tile('empty', x, y)
            elif level[y][x] == '#':
                Tile('wall', x, y)
            elif level[y][x] == '@':
                Tile('empty', x, y)
                new_player = Player(x, y)
    return new_player, x, y


player, level_x, level_y = generate_level(load_level('levelex.txt'))
full_lvl = load_level('levelex.txt')


class Camera:
    def __init__(self):
        self.dx = 0
        self.dy = 0

    def apply(self, obj):
        obj.rect.x += self.dx
        obj.rect.y += self.dy

    def update(self, target):
        self.dx = -(target.rect.x + target.rect.w // 2 - WIDTH // 2)
        self.dy = -(target.rect.y + target.rect.h // 2 - HEIGHT // 2)


# camera = Camera()


def terminate():
    pygame.quit()
    sys.exit()


def start_screen():
    intro_text = ["Заставка",
                  "",
                  "Правила игры",
                  "Если в правилах несколько строк",
                  "приходится выводить их посточно"
                  ]
    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 60
    for line in intro_text:
        string_render = font.render(line, 1, pygame.Color("black"))
        intro_rect = string_render.get_rect()
        intro_rect.top = text_coord
        intro_rect.x = 10
        screen.blit(string_render, intro_rect)
        text_coord += intro_rect.height + 10  # расстояние между строчками

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN:
                return
        pygame.display.flip()
        clock.tick(FPS)


start_screen()


# Главный Игровой цикл
running = True
while running:
    WIDTH, HEIGHT = pygame.display.get_window_size()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            terminate()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                if full_lvl[player.rect.y // tile_height][(player.rect.x - STEP) // tile_width]\
                        != '#':
                    player.rect.x -= STEP
            if event.key == pygame.K_RIGHT:
                if full_lvl[player.rect.y // tile_height][(player.rect.x + STEP) // tile_width]\
                        != '#':
                    player.rect.x += STEP
            if event.key == pygame.K_UP:
                if full_lvl[(player.rect.y - STEP) // tile_height][player.rect.x // tile_width]\
                        != '#':
                    player.rect.y -= STEP
            if event.key == pygame.K_DOWN:
                if full_lvl[(player.rect.y + STEP) // tile_height][player.rect.x // tile_width]\
                        != '#':
                    player.rect.y += STEP

    # camera.update(player)

    # for sprite in all_sprites:
        # camera.apply(sprite)

    screen.fill(pygame.Color(0, 0, 0))
    tiles_group.draw(screen)
    player_group.draw(screen)

    pygame.display.flip()
    clock.tick(FPS)

